// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_OC_INI_CCH_MAX ( 100 )

#define N_OC_INI_SECTION  n_posix_literal( "[OrangeCat]" )
#define N_OC_INI_VIEW     n_posix_literal( "view    " )
#define N_OC_INI_ICON     n_posix_literal( "icon    " )
#define N_OC_INI_BPP      n_posix_literal( "BPP     " )
#define N_OC_INI_STYLE    n_posix_literal( "style   " )
#define N_OC_INI_GALLERY  n_posix_literal( "gallery " )
#define N_OC_INI_FADE     n_posix_literal( "fade    " )
#define N_OC_INI_DWM      n_posix_literal( "DWM     " )
#define N_OC_INI_SMOOTH   n_posix_literal( "smooth  " )
#define N_OC_INI_TEXT     n_posix_literal( "text    " )
#define N_OC_INI_DRAGSEL  n_posix_literal( "dragsel " )
#define N_OC_INI_LINESEL  n_posix_literal( "linesel " )
#define N_OC_INI_ICON_RC  n_posix_literal( "icon_rc " )
#define N_OC_INI_SORT     n_posix_literal( "sort    " )
#define N_OC_INI_TOOLTIP  n_posix_literal( "tooltip " )
#define N_OC_INI_RICHTIP  n_posix_literal( "richtip " )
#define N_OC_INI_SHOW_LNK n_posix_literal( "show_lnk" )
#define N_OC_INI_THREAD   n_posix_literal( "thread  " )
#define N_OC_INI_HEADER   n_posix_literal( "header  " )

#define N_OC_INI_AUTO     n_posix_literal( "auto"     )




void
n_oc_ini_dwm_onoff( void )
{

	if ( oc.dwm_onoff )
	{
		game.dwm_onoff = n_true;
		game.color     = 0;
		n_game_dwm_on();
	} else {
		game.dwm_onoff = n_false;
		n_game_dwm_off();
	}


	return;
}

void
n_oc_ini_read( void )
{

	// [!] : Override

	n_string_path_folder_change( oc.home );


	// [!] : Start

	n_ini ini; n_ini_zero( &ini );

	n_bool is_first = n_ini_load( &ini, n_project_ini_name );


	// [!] : Shared

	int          cch = N_OC_INI_CCH_MAX;
	n_posix_char str[ N_OC_INI_CCH_MAX ];


	// [!] : View

	oc.view_type = N_ORANGECAT_VIEW_TYPE_ICON;

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_VIEW, N_STRING_EMPTY, str, cch );

	if ( n_string_is_same_literal( "logo", str ) ) { oc.view_type = N_ORANGECAT_VIEW_TYPE_LOGO; } else
	if ( n_string_is_same_literal( "icon", str ) ) { oc.view_type = N_ORANGECAT_VIEW_TYPE_ICON; } else
	if ( n_string_is_same_literal( "path", str ) ) { oc.view_type = N_ORANGECAT_VIEW_TYPE_PATH; } else
	if ( n_string_is_same_literal( "date", str ) ) { oc.view_type = N_ORANGECAT_VIEW_TYPE_DATE; } else
	if ( n_string_is_same_literal( "size", str ) ) { oc.view_type = N_ORANGECAT_VIEW_TYPE_SIZE; }


	// [!] : Icon Size

	oc.unit_rsrc = 32;

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_ICON, N_STRING_EMPTY, str, cch );

	if ( n_string_is_same_literal(  "16", str ) ) { oc.unit_rsrc =  16; } else
	if ( n_string_is_same_literal(  "24", str ) ) { oc.unit_rsrc =  24; } else
	if ( n_string_is_same_literal(  "32", str ) ) { oc.unit_rsrc =  32; } else
	if ( n_string_is_same_literal(  "48", str ) ) { oc.unit_rsrc =  48; } else
	if ( n_string_is_same_literal(  "64", str ) ) { oc.unit_rsrc =  64; } else
	if ( n_string_is_same_literal( "256", str ) ) { oc.unit_rsrc = 256; }


	// [!] : Icon BPP

	oc.unit__bpp = 32;

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_ICON, N_STRING_EMPTY, str, cch );

	if ( n_string_is_same_literal(  "4", str ) ) { oc.unit__bpp =  4; } else
	if ( n_string_is_same_literal(  "8", str ) ) { oc.unit__bpp =  8; } else
	if ( n_string_is_same_literal( "24", str ) ) { oc.unit__bpp = 24; } else
	if ( n_string_is_same_literal( "32", str ) ) { oc.unit__bpp = 32; }


	// [!] : Style

	extern void n_oc_style_autoselect( void );
	n_oc_style_autoselect();

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_STYLE, N_OC_INI_AUTO, str, cch );

	oc.style_auto = n_false;

	if ( is_first )
	{
		oc.style_auto = n_true;
	} else
	if ( n_string_is_same_literal(    "auto", str ) )
	{
		oc.style_auto = n_true;
	} else
	if ( n_string_is_same_literal( "classic", str ) )
	{
		oc.style = N_ORANGECAT_STYLE_CLASSIC;
	} else
	if ( n_string_is_same_literal(    "luna", str ) )
	{
		oc.style = N_ORANGECAT_STYLE_LUNA;
	} else
	if ( n_string_is_same_literal(    "aero", str ) )
	{
		oc.style = N_ORANGECAT_STYLE_AERO;
	} else
	if ( n_string_is_same_literal(       "8", str ) )
	{
		oc.style = N_ORANGECAT_STYLE_8;
	} else
	if ( n_string_is_same_literal(    "aqua", str ) )
	{
		oc.style = N_ORANGECAT_STYLE_AQUA;
	}// else


	// [!] : Gallery

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_GALLERY, N_STRING_EMPTY, str, cch );

	oc.view_gallery_step = 8;
	oc.view_gallery_size = n_posix_max_s32( oc.unit_icon, n_posix_atoi( str ) );


	oc.view_gallery_style = N_GDI_ICON_IMAGELOADER;
	oc.view_icon_fxsize   = 0;
	oc.view_text_fxsize   = oc.unit_scal;


	// [!] : Fade

	// [!] : n_oc_style_autoselect() sets default

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_FADE, N_OC_INI_AUTO, str, cch );

	if ( n_string_is_same_literal( "off", str ) )
	{
		oc.fade_onoff       = n_false;
		oc.transition_onoff = n_false;
		oc.transition_type  = N_GAME_TRANSITION_FADE;
	} else
	if ( n_string_is_same_literal(  "on", str ) )
	{
		oc.fade_onoff       = n_true;
		oc.transition_onoff = n_true;
		oc.transition_type  = N_GAME_TRANSITION_FADE;
	}


	// [!] : DWM

	oc.dwm_onoff = n_false;

	if ( game.dwm_onoff )
	{
		if ( n_sysinfo_version_vista() )
		{
			oc.dwm_onoff = n_true;
		} else
		if ( n_sysinfo_version_7() )
		{
			oc.dwm_onoff = n_true;
		}// else
	}

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_DWM, N_OC_INI_AUTO, str, cch );

	if ( n_string_is_same_literal( "off", str ) )
	{
		oc.dwm_onoff = n_false;
	} else
	if ( n_string_is_same_literal(  "on", str ) )
	{
		oc.dwm_onoff = n_true;
	}

	if ( n_win_darkmode_onoff ) { oc.dwm_onoff = n_false; }

	n_oc_ini_dwm_onoff();


	// [!] : Smooth and Text Size

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_SMOOTH, N_OC_INI_AUTO, str, cch );

	oc.font_smooth_auto = n_true;

	if ( n_string_is_same_literal( "off", str ) )
	{
		oc.font_smooth_auto  = n_false;
		oc.font_smooth_onoff = n_false;
	} else
	if ( n_string_is_same_literal(  "on", str ) )
	{
		oc.font_smooth_auto  = n_false;
		oc.font_smooth_onoff = n_true;
	}

	n_oc_font_init( oc.font_smooth_auto, oc.font_smooth_onoff );


	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_TEXT, N_STRING_EMPTY, str, cch );

	if ( 0 != n_posix_atoi( str ) )
	{
		n_oc_font_size = n_posix_atoi( str );
	}


	// [!] : Drag Selection Mode

	extern void n_oc_reset_dragselection_alpha( void );
	n_oc_reset_dragselection_alpha();

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_DRAGSEL, N_OC_INI_AUTO, str, cch );

	if ( n_string_is_same_literal( "dot"  , str ) )
	{
		oc.dragselection_alpha_onoff = n_false;
	} else
	if ( n_string_is_same_literal( "alpha", str ) )
	{
		oc.dragselection_alpha_onoff = n_true;
	}


	// [!] : Whole Line Selection in Path/Date View

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_LINESEL, N_OC_INI_AUTO, str, cch );

	oc.lineselection_onoff = n_true;

	if ( n_string_is_same_literal( "off", str ) )
	{
		oc.lineselection_onoff = n_false;
	} else
	if ( n_string_is_same_literal(  "on", str ) )
	{
		oc.lineselection_onoff = n_true;
	}


	// [!] : Icon Resource

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_ICON_RC, N_OC_INI_AUTO, str, cch );

	oc.icon_resource = N_GDI_ICON_RESOURCE | N_GDI_ICON_RC_RESOLVE;

	if ( n_string_is_same_literal( "off", str ) )
	{
		oc.icon_resource = N_GDI_ICON_DEFAULT;
	} else
	if ( n_string_is_same_literal(  "on", str ) )
	{
		oc.icon_resource = N_GDI_ICON_RESOURCE | N_GDI_ICON_RC_RESOLVE;
	}


	// [!] : Sort Option

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_SORT, N_OC_INI_AUTO, str, cch );

	if (
		( n_string_is_empty( str ) )
		||
		( n_string_is_same( N_OC_INI_AUTO, str ) )
		||
		(
			( n_false == n_string_is_same_literal( "explorer", str ) )
			&&
			( n_false == n_string_is_same_literal( "nonnon"  , str ) )
			&&
			( n_false == n_string_is_same_literal( "charcode", str ) )
		)
	)
	{
		if ( n_sysinfo_version_7_or_later() )
		{
#ifdef UNICODE
			n_posix_sprintf_literal( str, "explorer" );
#else  // #ifdef UNICODE
			n_posix_sprintf_literal( str, "nonnon"   );
#endif // #ifdef UNICODE
		} else {
			n_posix_sprintf_literal( str, "nonnon"   );
		}
	}

	if ( n_string_is_same_literal( "explorer", str ) )
	{
		n_string_compare_charcode_only        = n_false;
		n_string_compare_CompareString_onoff  = n_true;
		n_string_compare_custom_callback_func = NULL;
	} else
	if ( n_string_is_same_literal( "nonnon", str ) )
	{
		n_string_compare_charcode_only        = n_false;
		n_string_compare_CompareString_onoff  = n_false;
		n_string_compare_custom_callback_func = n_string_compare_explorer_compatible;
	} else
	if ( n_string_is_same_literal( "charcode", str ) )
	{
		n_string_compare_charcode_only        = n_true;
		n_string_compare_CompareString_onoff  = n_false;
		n_string_compare_custom_callback_func = NULL;
	}


	// [!] : Tooltip Mode

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_TOOLTIP, N_OC_INI_AUTO, str, cch );

	oc.tooltip_mode = N_ORANGECAT_TOOLTIP_NONE;

	if ( n_string_is_same_literal( "auto", str ) )
	{
		oc.tooltip_mode = N_ORANGECAT_TOOLTIP_TOOLTIP;
	} else
	if ( n_string_is_same_literal( "tooltip", str ) )
	{
		oc.tooltip_mode = N_ORANGECAT_TOOLTIP_TOOLTIP;
	} else
	if ( n_string_is_same_literal( "caption", str ) )
	{
		oc.tooltip_mode = N_ORANGECAT_TOOLTIP_CAPTION;
	} else
	if ( n_string_is_same_literal( "both", str ) )
	{
		oc.tooltip_mode = N_ORANGECAT_TOOLTIP_TOOLTIP | N_ORANGECAT_TOOLTIP_CAPTION;
	}// else


	// [!] : Rich Tooltip

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_RICHTIP, N_OC_INI_AUTO, str, cch );

	oc.tooltip_richtip_onoff = n_true;

	if ( n_string_is_same_literal( "auto", str ) )
	{
		//
	} else
	if ( n_string_is_same_literal(  "off", str ) )
	{
		oc.tooltip_richtip_onoff = n_false;
	} else
	if ( n_string_is_same_literal(   "on", str ) )
	{
		oc.tooltip_richtip_onoff = n_true;
	}


	// [!] : Shortcut files (".LNK") resolver

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_SHOW_LNK, N_OC_INI_AUTO, str, cch );

	oc.lnk_onoff = n_false;

	if ( n_string_is_same_literal( "auto", str ) )
	{
		//
	} else
	if ( n_string_is_same_literal(  "off", str ) )
	{
		oc.lnk_onoff = n_false;
	} else
	if ( n_string_is_same_literal(   "on", str ) )
	{
		oc.lnk_onoff = n_true;
	}


	// [!] : Multi-Threaded

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_THREAD, N_OC_INI_AUTO, str, cch );

	oc.global_thread_onoff = n_true;

	if ( n_string_is_same_literal( "auto", str ) )
	{
		//
	} else
	if ( n_string_is_same_literal(  "off", str ) )
	{
		oc.global_thread_onoff = n_false;
	} else
	if ( n_string_is_same_literal(   "on", str ) )
	{
		oc.global_thread_onoff = n_true;
	}


	// [!] : Menu Header

	{

		n_posix_char *str_default = n_posix_literal( "off off off off on" );

		n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_HEADER, str_default, str, cch );

		n_posix_char ret[ 1024 ];

		n_string_parameter( str, N_STRING_SPACE, N_STRING_EMPTY, 0, ret );
		if ( n_string_is_same_literal( "on", ret ) )
		{
			n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_VIEW , 'H' );
		} else {
			n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_VIEW , 'h' );
		}

		n_string_parameter( str, N_STRING_SPACE, N_STRING_EMPTY, 1, ret );
		if ( n_string_is_same_literal( "on", ret ) )
		{
			n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_ICON , 'H' );
		} else {
			n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_ICON , 'h' );
		}

		n_string_parameter( str, N_STRING_SPACE, N_STRING_EMPTY, 2, ret );
		if ( n_string_is_same_literal( "on", ret ) )
		{
			n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_BPP  , 'H' );
		} else {
			n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_BPP  , 'h' );
		}

		n_string_parameter( str, N_STRING_SPACE, N_STRING_EMPTY, 3, ret );
		if ( n_string_is_same_literal( "on", ret ) )
		{
			n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE, 'H' );
		} else {
			n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE, 'h' );
		}

		n_string_parameter( str, N_STRING_SPACE, N_STRING_EMPTY, 4, ret );
		if ( n_string_is_same_literal( "on", ret ) )
		{
			n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_TOOL , 'H' );
		} else {
			n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_TOOL , 'h' );
		}

	}


	n_ini_free( &ini );


	if ( oc.view_is_computer == n_false ) { n_string_path_folder_change( oc.main ); }


	return;
}

void
n_oc_ini_write( void )
{

	// [!] : Override

	n_string_path_folder_change( oc.home );


	// [!] : Start

	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, n_project_ini_name );

	n_ini_section_add( &ini, N_OC_INI_SECTION );


	// [!] : Shared

	n_posix_char     view[ N_OC_INI_CCH_MAX ]; n_string_truncate(     view );
	n_posix_char     icon[ N_OC_INI_CCH_MAX ]; n_string_truncate(     icon );
	n_posix_char      bpp[ N_OC_INI_CCH_MAX ]; n_string_truncate(      bpp );
	n_posix_char    style[ N_OC_INI_CCH_MAX ]; n_string_truncate(    style );
	n_posix_char     fade[ N_OC_INI_CCH_MAX ]; n_string_truncate(     fade );
	n_posix_char  gallery[ N_OC_INI_CCH_MAX ]; n_string_truncate(  gallery );
	n_posix_char   smooth[ N_OC_INI_CCH_MAX ]; n_string_truncate(   smooth );
	n_posix_char     text[ N_OC_INI_CCH_MAX ]; n_string_truncate(     text );
	n_posix_char      dwm[ N_OC_INI_CCH_MAX ]; n_string_truncate(      dwm );
	n_posix_char  dragsel[ N_OC_INI_CCH_MAX ]; n_string_truncate(  dragsel );
	n_posix_char  linesel[ N_OC_INI_CCH_MAX ]; n_string_truncate(  linesel );
	n_posix_char  icon_rc[ N_OC_INI_CCH_MAX ]; n_string_truncate(  icon_rc );
	n_posix_char     sort[ N_OC_INI_CCH_MAX ]; n_string_truncate(     sort );
	n_posix_char  tooltip[ N_OC_INI_CCH_MAX ]; n_string_truncate(  tooltip );
	n_posix_char  richtip[ N_OC_INI_CCH_MAX ]; n_string_truncate(  richtip );
	n_posix_char show_lnk[ N_OC_INI_CCH_MAX ]; n_string_truncate( show_lnk );
	n_posix_char   thread[ N_OC_INI_CCH_MAX ]; n_string_truncate(   thread );
	n_posix_char   header[ N_OC_INI_CCH_MAX ]; n_string_truncate(   header );


	// [!] : View

	if ( oc.view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{
		n_string_copy_literal( "logo", view );
	} else
	if ( oc.view_type == N_ORANGECAT_VIEW_TYPE_ICON )
	{
		n_string_copy_literal( "icon", view );
	} else
	if ( oc.view_type == N_ORANGECAT_VIEW_TYPE_PATH )
	{
		n_string_copy_literal( "path", view );
	} else
	if ( oc.view_type == N_ORANGECAT_VIEW_TYPE_DATE )
	{
		n_string_copy_literal( "date", view );
	} else
	if ( oc.view_type == N_ORANGECAT_VIEW_TYPE_SIZE )
	{
		n_string_copy_literal( "size", view );
	}// else


	// [!] : Icon Size

	if ( oc.unit_rsrc ==  16 )
	{
		n_string_copy_literal(  "16", icon );
	} else
	if ( oc.unit_rsrc ==  24 )
	{
		n_string_copy_literal(  "24", icon );
	} else
	if ( oc.unit_rsrc ==  32 )
	{
		n_string_copy_literal(  "32", icon );
	} else
	if ( oc.unit_rsrc ==  48 )
	{
		n_string_copy_literal(  "48", icon );
	} else
	if ( oc.unit_rsrc ==  64 )
	{
		n_string_copy_literal(  "64", icon );
	} else
	if ( oc.unit_rsrc == 256 )
	{
		n_string_copy_literal( "256", icon );
	}


	// [!] : Icon BPP

	if ( oc.unit__bpp ==  4 )
	{
		n_string_copy_literal(  "4", bpp );
	} else
	if ( oc.unit__bpp ==  8 )
	{
		n_string_copy_literal(  "8", bpp );
	} else
	if ( oc.unit__bpp == 24 )
	{
		n_string_copy_literal( "24", bpp );
	} else
	if ( oc.unit__bpp == 32 )
	{
		n_string_copy_literal( "32", bpp );
	}


	// [!] : Style

	//n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_STYLE, N_OC_INI_AUTO, style, N_OC_INI_CCH_MAX );

	if ( oc.style_auto )
	{
		n_string_copy_literal( "auto",    style );
	} else
	if ( oc.style == N_ORANGECAT_STYLE_CLASSIC )
	{
		n_string_copy_literal( "classic", style );
	} else
	if ( oc.style == N_ORANGECAT_STYLE_LUNA )
	{
		n_string_copy_literal( "luna",    style );
	} else
	if ( oc.style == N_ORANGECAT_STYLE_AERO )
	{
		n_string_copy_literal( "aero",    style );
	} else
	if ( oc.style == N_ORANGECAT_STYLE_8 )
	{
		n_string_copy_literal( "8",       style );
	} else
	if ( oc.style == N_ORANGECAT_STYLE_AQUA )
	{
		n_string_copy_literal( "aqua",    style );
	}// else


	// [!] : Gallery

	n_posix_sprintf_literal( gallery, "%d", (int) oc.view_gallery_size );


	// [!] : Text Size

	n_posix_sprintf_literal( text, "%d", (int) n_oc_font_size );


	// [!] : Menu Header

	n_posix_char *str_on  = n_posix_literal( "on"  );
	n_posix_char *str_off = n_posix_literal( "off" );

	int header_cch = 0;
	if ( n_win_simplemenu_detect_literal( &oc.menu, N_ORANGECAT_MENU_VIEW , 'H' ) )
	{
		header_cch += n_posix_sprintf_literal( &header[ header_cch ], "%s", str_on  );
	} else {
		header_cch += n_posix_sprintf_literal( &header[ header_cch ], "%s", str_off );
	}

	if ( n_win_simplemenu_detect_literal( &oc.menu, N_ORANGECAT_MENU_ICON , 'H' ) )
	{
		header_cch += n_posix_sprintf_literal( &header[ header_cch ], " %s", str_on  );
	} else {
		header_cch += n_posix_sprintf_literal( &header[ header_cch ], " %s", str_off );
	}

	if ( n_win_simplemenu_detect_literal( &oc.menu, N_ORANGECAT_MENU_BPP  , 'H' ) )
	{
		header_cch += n_posix_sprintf_literal( &header[ header_cch ], " %s", str_on  );
	} else {
		header_cch += n_posix_sprintf_literal( &header[ header_cch ], " %s", str_off );
	}

	if ( n_win_simplemenu_detect_literal( &oc.menu, N_ORANGECAT_MENU_STYLE, 'H' ) )
	{
		header_cch += n_posix_sprintf_literal( &header[ header_cch ], " %s", str_on  );
	} else {
		header_cch += n_posix_sprintf_literal( &header[ header_cch ], " %s", str_off );
	}

	if ( n_win_simplemenu_detect_literal( &oc.menu, N_ORANGECAT_MENU_TOOL , 'H' ) )
	{
		header_cch += n_posix_sprintf_literal( &header[ header_cch ], " %s", str_on  );
	} else {
		header_cch += n_posix_sprintf_literal( &header[ header_cch ], " %s", str_off );
	}


	// [!] : no touch / follow user's setting

	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_FADE,     N_OC_INI_AUTO,     fade, N_OC_INI_CCH_MAX );
	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_DWM,      N_OC_INI_AUTO,      dwm, N_OC_INI_CCH_MAX );
	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_SMOOTH,   N_OC_INI_AUTO,   smooth, N_OC_INI_CCH_MAX );
	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_DRAGSEL,  N_OC_INI_AUTO,  dragsel, N_OC_INI_CCH_MAX );
	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_LINESEL,  N_OC_INI_AUTO,  linesel, N_OC_INI_CCH_MAX );
	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_ICON_RC,  N_OC_INI_AUTO,  icon_rc, N_OC_INI_CCH_MAX );
	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_SORT,     N_OC_INI_AUTO,     sort, N_OC_INI_CCH_MAX );
	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_TOOLTIP,  N_OC_INI_AUTO,  tooltip, N_OC_INI_CCH_MAX );
	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_RICHTIP,  N_OC_INI_AUTO,  richtip, N_OC_INI_CCH_MAX );
	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_SHOW_LNK, N_OC_INI_AUTO, show_lnk, N_OC_INI_CCH_MAX );
	n_ini_value_str( &ini, N_OC_INI_SECTION, N_OC_INI_THREAD  , N_OC_INI_AUTO,   thread, N_OC_INI_CCH_MAX );


	// [!] : Sort

	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_VIEW     );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_ICON     );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_BPP      );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_STYLE    );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_GALLERY  );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_FADE     );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_DWM      );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_SMOOTH   );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_TEXT     );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_DRAGSEL  );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_LINESEL  );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_ICON_RC  );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_SORT     );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_TOOLTIP  );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_RICHTIP  );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_SHOW_LNK );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_THREAD   );
	n_ini_key_del( &ini, N_OC_INI_SECTION, N_OC_INI_HEADER   );


	// [!] : Write

	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_VIEW    ,     view );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_ICON    ,     icon );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_BPP     ,      bpp );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_STYLE   ,    style );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_GALLERY ,  gallery );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_FADE    ,     fade );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_DWM     ,      dwm );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_SMOOTH  ,   smooth );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_TEXT    ,     text );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_DRAGSEL ,  dragsel );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_LINESEL ,  linesel );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_ICON_RC ,  icon_rc );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_SORT    ,     sort );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_TOOLTIP ,  tooltip );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_RICHTIP ,  richtip );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_SHOW_LNK, show_lnk );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_THREAD  ,   thread );
	n_ini_key_add_str( &ini, N_OC_INI_SECTION, N_OC_INI_HEADER  ,   header );


	// [!] : Cleanup

	n_ini_save( &ini, n_project_ini_name );
	n_ini_free( &ini );


	if ( oc.view_is_computer == n_false ) { n_string_path_folder_change( oc.main ); }


	n_explorer_refresh( n_false );


	return;
}

