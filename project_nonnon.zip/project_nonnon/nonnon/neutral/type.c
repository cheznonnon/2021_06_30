// Nonnon General Types
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_NEUTRAL_TYPE
#define _H_NONNON_NEUTRAL_TYPE




#define s8           char
#define s16          short
#define s32          long
#define s64          long long

#define u8  unsigned char
#define u16 unsigned short
#define u32 unsigned long
#define u64 unsigned long long




#endif // _H_NONNON_NEUTRAL_TYPE

