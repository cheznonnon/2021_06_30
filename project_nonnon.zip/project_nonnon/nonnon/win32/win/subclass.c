// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Memo ]
//
//	[ All ]
//
//	you cannot stop all rendering operation
//	WM_PAINT and WM_NCPAINT are not enough
//
//	WM_SETTINGCHANGE never comes here
//
//	SetProp() : distinction among each item is not possible
//
//
//	[ Edit ]
//
//	currently not stable under DWM
//
//
//	[ Static ]
//
//	this cannot be custom control host, use SS_OWNERDRAW instead
//	Win95 : double-buffering doesn't function
//
//
//	[ Scrollbar ]
//
//	GDI handle leak : don't set HFONT to scrollbars




#ifndef _H_NONNON_WIN32_WIN_SUBCLASS
#define _H_NONNON_WIN32_WIN_SUBCLASS




#include "./_debug.c"




#ifdef _WIN64


// [x] : Buggy : GetWindowLongPtr( hwnd, GWLP_WNDPROC ) returns an invalid pointer
//
//	use SetWindowSubclass()/RemoveWindowSubclass() and DefSubclassProc()

/*
SetWindowSubclass( hgui, subclass, 0, p );

LRESULT CALLBACK
subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
{

	data_t *p = (void*) dwRefData;
	if ( p == NULL ) { return 0; }


	return DefSubclassProc( hwnd, msg, wparam, lparam );
}
*/


#include <commctrl.h>

#pragma comment( lib, "comctl32" )


#else  // #ifdef _WIN64


// [!] : GCC4.x macro expansion behavior is changed
//
//	you cannot use #define n_win_gui_subclass_get( hwnd ) (WNDPROC) GetWindowLong( hwnd, GWL_WNDPROC )

WNDPROC
n_win_gui_subclass_get( HWND hwnd )
{
	return (WNDPROC) GetWindowLong( hwnd, GWL_WNDPROC );
}

WNDPROC
n_win_gui_subclass_set( HWND hwnd, WNDPROC func )
{
	return (WNDPROC) SetWindowLong( hwnd, GWL_WNDPROC, (LONG) func );
}


#endif // #ifdef _WIN64


// Components

#include "./subclass/edit.c"
#include "./subclass/txtbox.c"




#endif // _H_NONNON_WIN32_WIN_SUBCLASS

