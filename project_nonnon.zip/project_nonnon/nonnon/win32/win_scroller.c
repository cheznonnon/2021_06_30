// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ n_win_scrollbar_scroll_unit() ]
//
//		this modulie calls WM_COMMAND
//		so infinite loop or crash happen easily




#ifndef _H_NONNON_WIN32_WIN_SCROLLER
#define _H_NONNON_WIN32_WIN_SCROLLER




#include "../neutral/posix.c"




#include "./win/dwm.c"
#include "./win/gui.c"
#include "./win/move.c"
#include "./win_scrollbar.c"




#define nwscr_move   n_win_scroller_move
#define nwscr_show   n_win_scroller_show
#define nwscr_enable n_win_scroller_enable




#define N_WIN_SCROLLER_NAMESPACE n_posix_literal( "Nonnon.Win.Scroller" )




typedef struct {

	HWND            label;
	HWND            value;
	n_win_scrollbar scrollbar;

	WNDPROC         pfunc;

	s32             text__y;
	s32             text_sy;

} n_win_scroller;



#define N_WIN_SCROLLER_VALUE_CCH_MAX ( 100 )




#define n_win_scroller_zero( p ) n_memory_zero( p, sizeof( n_win_scroller ) )

void
n_win_scroller_move( n_win_scroller *s, s32 x, s32 y, s32 sx, s32 sy, n_posix_bool redraw )
{

	s32 m; n_win_stdsize( s->scrollbar.hwnd, NULL, NULL, &m );


	const s32 unit = sx / 10;

	s32 lsx = ( unit * 2 );
	s32 vsx = ( unit * 2 );
	s32 ssx = ( unit * 6 ) + ( sx % 10 ) - ( m * 2 ) - m;
	s32 olv = lsx + vsx;

	s32 scr_sy = n_win_scrollbar_stdsize( &s->scrollbar );
	s32 scr__y = ( ( sy - scr_sy ) / 2 ) - m;

	s32 txt_sy; n_win_stdsize_text( s->label, n_posix_literal( "0" ), NULL, &txt_sy );
	s32 txt__y = ( ( sy - txt_sy ) / 2 ) - m;

	n_win_move_simple   (  s->label    , x+    m+m, y+m+txt__y, lsx, txt_sy, redraw );
	n_win_move_simple   (  s->value    , x+lsx+m+m, y+m+txt__y, vsx, txt_sy, redraw );
	n_win_scrollbar_move( &s->scrollbar, x+olv+m+m, y+m+scr__y, ssx, scr_sy, redraw );

	// [Patch] : for some timing error
/*
	if ( redraw )
	{
		s->scrollbar.fade_thumb   .stop = n_posix_false;
		s->scrollbar.fade_arrow_ul.stop = n_posix_false;
		s->scrollbar.fade_arrow_dr.stop = n_posix_false;
	}
*/
	s->text__y = y + m + txt__y;
	s->text_sy = txt_sy;


	return;
}

void
n_win_scroller_show( n_win_scroller *s, int show )
{

	ShowWindow( s->label , show );
	ShowWindow( s->value , show );

	n_posix_bool onoff;
	if ( show == SW_HIDE ) { onoff = n_posix_false; } else { onoff = n_posix_true; }
	n_win_scrollbar_show( &s->scrollbar, onoff );


	return;
}

void
n_win_scroller_enable( n_win_scroller *s, n_posix_bool enable )
{

	EnableWindow( s->label, enable );
	EnableWindow( s->value, enable );

	n_win_scrollbar_enable( &s->scrollbar, enable, n_posix_true );


	return;
}

HWND
n_win_scroller_scroll_hwnd( n_win_scroller *s )
{
	return s->scrollbar.hwnd;
}

int
n_win_scroller_value_get( n_win_scroller *s )
{

	int           cch = GetWindowTextLength( s->value );
	n_posix_char *str = n_string_new( cch ); GetWindowText( s->value, str, cch + 1 );
	int           ret = n_posix_atoi( str );

	n_string_free( str );


	return ret;
}

void
n_win_scroller_scroll_refresh( n_win_scroller *s )
{

	n_win_scrollbar_refresh( &s->scrollbar );


	return;
}

void
n_win_scroller_scroll_parameter( n_win_scroller *s, double step, double page, double max, double pos, n_posix_bool redraw )
{

	n_win_scrollbar_parameter( &s->scrollbar, step, page, max, pos, redraw );

	if ( redraw )
	{
		s->scrollbar.unit_pos = 0;
		n_win_scrollbar_scroll_unit( &s->scrollbar, pos, N_WIN_SCROLLBAR_SCROLL_AUTO );
	}


	return;
}

LRESULT
n_win_scroller_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_scroller *s )
{

	switch( msg ) {


	case WM_MOUSEWHEEL :

		if ( n_win_is_hovered( s->scrollbar.hwnd ) )
		{
			int delta = n_win_scrollbar_wheeldelta( wparam, 0, n_posix_false ) * -1;

			n_win_scrollbar_scroll_unit( &s->scrollbar, delta, N_WIN_SCROLLBAR_SCROLL_AUTO );
			n_win_scrollbar_draw_always( &s->scrollbar, n_posix_true );

			n_win_message_send( hwnd, WM_COMMAND, s->scrollbar.unit_pos, s->scrollbar.hwnd );
		}

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret != 0 ) { return ret; }
	}


	n_win_scrollbar_proc( hwnd, msg, wparam, lparam, &s->scrollbar );
	n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &s->scrollbar );


	return 0;
}

void
n_win_scroller_on_settingchange( n_win_scroller *s )
{

	n_win_stdfont_init( &s->label, 1 );
	n_win_stdfont_init( &s->value, 1 );

	n_win_scrollbar_on_settingchange( &s->scrollbar, n_posix_true, n_posix_true );

	n_win_refresh( s->label         , n_posix_true );
	n_win_refresh( s->value         , n_posix_true );
	n_win_refresh( s->scrollbar.hwnd, n_posix_true );


	return;
}

#define n_win_scroller_init_literal( s, h, l ) n_win_scroller_init( s, h, n_posix_literal( l ) )

void
n_win_scroller_init( n_win_scroller *s, HWND hwnd_parent, n_posix_char *label )
{

	n_win_gui( hwnd_parent, N_WIN_GUI_LABEL ,          label, &s->label  );
	n_win_gui( hwnd_parent, N_WIN_GUI_LABEL , N_STRING_EMPTY, &s->value  );


	int style = N_WIN_SCROLLBAR_STYLE_AUTO;
	n_win_scrollbar_init( &s->scrollbar, hwnd_parent, N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL, style );
	s->scrollbar.option |= N_WIN_SCROLLBAR_OPTION_BIG_ARROWS;


	n_win_style_del( s->label, SS_CENTER );
	n_win_style_del( s->value, SS_CENTER );

	//n_win_style_add( s->value, SS_LEFT   );
	//n_win_style_add( s->value, SS_RIGHT  );


	n_win_stdfont_init( &s->label, 1 );
	n_win_stdfont_init( &s->value, 1 );


	return;
}

void
n_win_scroller_exit( n_win_scroller *s )
{

	n_win_stdfont_exit( &s->label, 1 );
	n_win_stdfont_exit( &s->value, 1 );

	n_win_scrollbar_exit( &s->scrollbar );

	DestroyWindow( s->label  );
	DestroyWindow( s->value  );


	n_win_scroller_zero( s );


	return;
}


#endif // _H_NONNON_WIN32_WIN_SCROLLER

