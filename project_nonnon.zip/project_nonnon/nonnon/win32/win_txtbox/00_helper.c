// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




inline n_posix_bool
n_win_txtbox_timer( u32 *prv, u32 interval )
{

	u32 cur = n_posix_tickcount();
	u32 msec;


	if ( (*prv) > cur )
	{
		msec = cur + ( 0xffff - (*prv) );
	} else {
		msec = cur - (*prv);
	}

	if ( msec >= interval )
	{
		(*prv) = cur;

		return n_posix_true;
	}


	return n_posix_false;
}

n_posix_bool
n_win_txtbox_filename_is_safe_char( n_posix_char c )
{

	if ( c == n_posix_literal( '\t' ) ) { return n_posix_false; }
	if ( c == n_posix_literal( '\\' ) ) { return n_posix_false; }
	if ( c == n_posix_literal( '/'  ) ) { return n_posix_false; }
	if ( c == n_posix_literal( ':'  ) ) { return n_posix_false; }
	if ( c == n_posix_literal( '*'  ) ) { return n_posix_false; }
	if ( c == n_posix_literal( '?'  ) ) { return n_posix_false; }
	if ( c == n_posix_literal( '\"' ) ) { return n_posix_false; }
	if ( c == n_posix_literal( '<'  ) ) { return n_posix_false; }
	if ( c == n_posix_literal( '>'  ) ) { return n_posix_false; }
	if ( c == n_posix_literal( '|'  ) ) { return n_posix_false; }


	return n_posix_true;
}

n_posix_bool
n_win_txtbox_filename_is_safe( n_posix_char *str )
{

	if ( n_string_is_empty( str ) ) { return n_posix_false; }


	n_posix_bool is_space = 0;

	int i = 0;
	while( 1 )
	{
		if ( i >= INT_MAX ) { return n_posix_false; }

		if ( str[ i ] == N_STRING_CHAR_NUL ) { break; }

		if ( i == 0 )
		{
			if ( str[ i ] == N_STRING_CHAR_SPACE ) { is_space = n_posix_true; }
		} else
		if ( ( is_space )&&( str[ i ] != N_STRING_CHAR_SPACE ) )
		{
			return n_posix_false;
		}

		i++;
	}

	if ( is_space ) { return n_posix_false; }


	i = 0;
	while( 1 )
	{
		if ( str[ i ] == N_STRING_CHAR_NUL ) { break; }

		n_posix_bool ret = n_win_txtbox_filename_is_safe_char( str[ i ] );
		if ( ret == n_posix_false ) { return n_posix_false; }

		i++;
	}


	return n_posix_true;
}

n_posix_bool
n_win_txtbox_filename_is_digit( n_posix_char *str )
{

	if ( n_string_is_empty( str ) ) { return n_posix_false; }


	int i = 0;
	while( 1 )
	{
		if ( i >= INT_MAX ) { return n_posix_false; }

		if ( str[ i ] == N_STRING_CHAR_NUL ) { break; }

		if ( n_posix_false == n_string_is_digit( str, i ) )
		{
			return n_posix_false;
		}

		i++;
	}


	return n_posix_true;
}

// internal
n_posix_bool
n_win_txtbox_is_accentmark_char( n_posix_char c )
{

	n_posix_bool ret = n_posix_false;


#ifdef UNICODE

	if ( ( c >= 0x0300 )&&( c <= 0x036f ) )
	{
		ret = n_posix_true;
	} else
	if ( ( c >= 0x1ab0 )&&( c <= 0x1ac0 ) )
	{
		ret = n_posix_true;
	} else
	if ( ( c >= 0x1dc0 )&&( c <= 0x1dff ) )
	{
		ret = n_posix_true;
	} else
	if ( ( c >= 0x20d0 )&&( c <= 0x20f0 ) )
	{
		ret = n_posix_true;
	} else
	if ( (c >=  0xfe20 )&&( c <= 0xfeff ) )
	{
		ret = n_posix_true;
	}

#endif // #ifdef UNICODE


	return ret;
}


// internal
n_posix_bool
n_win_txtbox_is_right2left_is_base_char( n_posix_char c )
{

	n_posix_bool ret = n_posix_false;


	// [x] : currently not supported

	//return ret;


#ifdef UNICODE

	// [!] : Arabic alphabet

	if ( ( c >= 0x0627 )&&( c <= 0x064a ) )
	{
		ret = n_posix_true;
	}

	// [!] : Hebrew alphabet

	if ( ( c >= 0x05d0 )&&( c <= 0x05ea ) )
	{
		ret = n_posix_true;
	}

#endif // #ifdef UNICODE


	return ret;
}

// internal
n_posix_bool
n_win_txtbox_is_right2left_char( n_posix_char c )
{

	n_posix_bool ret = n_posix_false;


	// [x] : currently not supported

	//return ret;


#ifdef UNICODE

	// [!] : Arabic alphabet

	if (
		( ( c >= 0x0600 )&&( c <= 0x06ff ) )
		||
		( ( c >= 0x0750 )&&( c <= 0x077f ) )
		||
		( ( c >= 0x08a0 )&&( c <= 0x08ff ) )
		||
		( ( c >= 0xfb50 )&&( c <= 0xfdff ) )
		||
		( ( c >= 0xfe70 )&&( c <= 0xfeff ) )
	)
	{
		ret = n_posix_true;
	}

	// [!] : Hebrew alphabet

	if (
		( ( c >= 0x0590 )&&( c <= 0x05ff ) )
		||
		( ( c >= 0xfb1d )&&( c <= 0xfb4f ) )
	)
	{
		ret = n_posix_true;
	}

#else  // #ifdef UNICODE

	// [!] : Arabic
/*
	if ( 1256 == GetACP() )
	{
		if ( c >= 0x80 ) { ret = n_posix_true; }
	}
*/

	// [!] : Hebrew
/*
	if ( 1255 == GetACP() )
	{
		if ( c >= 0xc0 ) { ret = n_posix_true; }
	}
*/

#endif // #ifdef UNICODE


	return ret;
}

// internal
n_posix_bool
n_win_txtbox_is_right2left_string( n_posix_char *str )
{

	n_posix_bool ret = n_posix_false;


	// [x] : currently not supported

	//return ret;


	int i = 0;
	while( 1 )
	{
		if ( i >= INT_MAX ) { return n_posix_false; }

		if ( str[ i ] == N_STRING_CHAR_NUL ) { break; }

		if ( n_win_txtbox_is_right2left_char( str[ i ] ) )
		{
			ret = n_posix_true;
			break;
		}

		i++;
	}


	return ret;
}

// internal
n_posix_bool
n_win_txtbox_is_fullwidth( n_posix_char c )
{

#ifdef UNICODE

	// [x] : why edit control uses too strict range
	//
	//	maybe compatibility with IME causes this 

	if ( c <= 127 )
	{

		// [!] : ASCII compatible code

		return n_posix_false;

	} else
	if (
/*
		(						// 8448 - 8703
			( c == 8470 )
			||
			( ( c >=  8544 )&&( c <=  8578 ) )
		)
		||
		(						// 8704 - 8959
			( ( c >=  8704 )&&( c <=  8748 ) )
			||
			( c == 8750 )
		)
		||
		( ( c >=  8960 )&&( c <=  9215 ) )		// 8960 - 9215 
		||
		( ( c >=  9312 )&&( c <=  9471 ) )		// 9216 - 9471
		||
		(						// 9472 - 9727
			( ( c >=  9472 )&&( c <=  9475 ) )
			||
			( c == 9484 )
			||
			( ( c >=  9622 )&&( c <=  9633 ) )
			||
			( ( c >=  9670 )&&( c <=  9671 ) )
			||
			( ( c >=  9678 )&&( c <=  9679 ) )
		)
		||
*/
		( ( c >= 0x2600 )&&( c <= 0x26ff ) )		//  9728 -  9983
		||
		( ( c >= 0x2700 )&&( c <= 0x27ff ) )		//  9984 - 10239
		||
		( ( c >= 0x2e00 )&&( c <= 0x2eff ) )		// 11766 - 12031
		||
		( ( c >= 0x2f00 )&&( c <= 0x2fff ) )		// 12032 - 12287
		||
		( ( c >= 0x3000 )&&( c <= 0xd7ff ) )		// 12288 - 55295
		||
		( ( c >= 0xff00 )&&( c <= 0xff60 ) )		// 65280 - 65376 : 0xff61 or above : includes "half-width kana"
	)
	{
		return n_posix_true;
	}


	wchar_t w[ 2 ] = { c, L'\0' };
	 char   a[ 3 ] = { '\0', '\0', '\0' };

	WideCharToMultiByte( CP_ACP, 0, w,2, a,3, NULL,NULL );

	if ( 1 < strlen( a ) ) { return n_posix_true; } 

#endif // #ifdef UNICODE


	return n_posix_false;
}




// internal
HFONT
n_win_txtbox_font_effect( HFONT hfont, n_posix_bool is_bold, n_posix_bool is_italic, n_posix_bool is_underline, n_posix_bool is_strikeout )
{

	LOGFONT lf = n_win_font_hfont2logfont( hfont );


	if ( is_bold      ) { lf.lfWeight    =      FW_BOLD; }
	if ( is_italic    ) { lf.lfItalic    = n_posix_true; }
	if ( is_underline ) { lf.lfUnderline = n_posix_true; }
	if ( is_strikeout ) { lf.lfStrikeOut = n_posix_true; }


	return n_win_font_logfont2hfont( &lf );
}

// internal
HFONT
n_win_txtbox_font_effect_no_underline( HFONT hfont )
{

	LOGFONT lf = n_win_font_hfont2logfont( hfont );

	lf.lfUnderline = n_posix_false;

	return n_win_font_logfont2hfont( &lf );
}

void
n_win_txtbox_frame( HDC hdc, s32 x, s32 y, s32 sx, s32 sy, COLORREF color )
{

	// [!] : Classic Theme : alpha value causes black-out

	color &= 0x00ffffff;


	s32 fx,fy,tx,ty;


	HGDIOBJ hp = SelectObject( hdc, CreatePen( PS_SOLID, 1, color ) );


	// Top-Bottom

	fx = x; tx = fx + sx;

	fy = y; ty = fy;
	MoveToEx( hdc, fx,fy, NULL ); LineTo( hdc, tx,ty );
	ExcludeClipRect( hdc, fx,fy,tx,ty+1 );

	fy = y + sy - 1; ty = fy;
	MoveToEx( hdc, fx,fy, NULL ); LineTo( hdc, tx,ty );
	ExcludeClipRect( hdc, fx,fy,tx,ty+1 );


	// Left-Right

	fy = y; ty = fy + sy;

	fx = x; tx = fx;
	MoveToEx( hdc, fx,fy, NULL ); LineTo( hdc, tx,ty );
	ExcludeClipRect( hdc, fx,fy,tx+1,ty );

	fx = x + sx - 1; tx = fx;
	MoveToEx( hdc, fx,fy, NULL ); LineTo( hdc, tx,ty );
	ExcludeClipRect( hdc, fx,fy,tx+1,ty );


	DeleteObject( SelectObject( hdc, hp ) );


	return;
}

#define n_win_txtbox_caret_l( line, x, ret ) n_win_txtbox_caret( line, x,  ret, NULL, NULL )
#define n_win_txtbox_caret_m( line, x, ret ) n_win_txtbox_caret( line, x, NULL,  ret, NULL )
#define n_win_txtbox_caret_r( line, x, ret ) n_win_txtbox_caret( line, x, NULL, NULL,  ret )

void
n_win_txtbox_caret( const n_posix_char *line, s32 x, s32 *ret_l, s32 *ret_m, s32 *ret_r )
{

	if ( x < 0 ) { return; }

	s32 l = 0;
	s32 m = 0;
	s32 r = 0;

#ifdef UNICODE

	l = m = r = x;


	if ( l > 0 ) { l--; }
	if ( n_unicode_surrogatepair_is_lo( line[ l ] ) )
	{
		if ( l > 0 ) { l--; }
	}


	if ( line[ r ] != N_STRING_CHAR_NUL )
	{

		r++;
		if ( n_unicode_surrogatepair_is_lo( line[ r ] ) )
		{

			if ( line[ r ] != N_STRING_CHAR_NUL )
			{
				r++;
			}

		} else {

			while( 1 )
			{

				if ( line[ r ] == N_STRING_CHAR_NUL ) { break; }

				if ( n_posix_false == n_win_txtbox_is_accentmark_char( line[ r ] ) ) { break; }

				r++;

			}

		}

	}

#else // #ifdef UNICODE

	while( 1 )
	{

		if ( line[ m ] == N_STRING_CHAR_NUL ) { break; }

		s32 unit = n_string_doublebyte_increment( line[ m ] );

		r = m + unit;

		if ( ( x >= m )&&( x < r ) ) { break; }

		l = m;
		m = r;

	}

#endif // #ifdef UNICODE

	if ( ret_l != NULL ) { (*ret_l) = l; }
	if ( ret_m != NULL ) { (*ret_m) = m; }
	if ( ret_r != NULL ) { (*ret_r) = r; }


	return;
}

COLORREF
n_win_txtbox_color_hue_tweak( COLORREF color, int offset )
{

	int r = GetRValue( color );
	int g = GetGValue( color );
	int b = GetBValue( color );

	u32 ahsl = n_bmp_argb2ahsl( n_bmp_rgb( r,g,b ) );

	int h = n_bmp_h( ahsl ) + offset;
	int s = n_bmp_s( ahsl );
	int l = n_bmp_l( ahsl );

	color = n_bmp_ahsl2argb( n_bmp_hsl( h,s,l ) );

	r = n_bmp_r( color );
	g = n_bmp_g( color );
	b = n_bmp_b( color );


	return RGB( r,g,b );
}


