// Game Template
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/game/timegettime.c"

#include "../nonnon/game/game.c"

//#include "../nonnon/game/chara.c"
//#include "../nonnon/game/click.c"
//#include "../nonnon/game/hmidiout.c"
//#include "../nonnon/game/input.c"
//#include "../nonnon/game/map.c"
//#include "../nonnon/game/map_chara.c"
//#include "../nonnon/game/pmr.c"
//#include "../nonnon/game/progressbar.c"
//#include "../nonnon/game/rc.c"
//#include "../nonnon/game/sound.c"
//#include "../nonnon/game/transition.c"




void
n_game_init( void )
{

	// System

	n_game_title_literal( "Game Template" );

	game.sx    = 320;
	game.sy    = 240;
	game.fps   = 30;
	game.color = n_bmp_white;


	return;
}

void
n_game_loop( void )
{
	return;
}

void
n_game_exit( void )
{
	return;
}

