// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#define N_PAINT_MENU_PREVIEW    0
#define N_PAINT_MENU_LINE1      1
#define N_PAINT_MENU_GRID       2
#define N_PAINT_MENU_PIXELGRID  3
#define N_PAINT_MENU_THUMBNAIL  4
#define N_PAINT_MENU_GRAYCANVAS 5
#define N_PAINT_MENU_LINE2      6
#define N_PAINT_MENU_CLR_CANVAS 7
#define N_PAINT_MENU_ALPHA      8
#define N_PAINT_MENU_REPLACER   9
#define N_PAINT_MENU_LINE3      10
#define N_PAINT_MENU_INI2GDI    11
#define N_PAINT_MENU_LINE4      12
#define N_PAINT_MENU_PROPERTY   13




void
n_paint_menu_init( void )
{

	n_win_simplemenu *p = &n_paint_simplemenu;

	n_win_simplemenu_set( p, N_PAINT_MENU_PREVIEW   , NULL, n_posix_literal( "[ ]1 : Preview"            ), NULL );
	n_win_simplemenu_set( p, N_PAINT_MENU_LINE1     , NULL, n_posix_literal( "[-]"                       ), NULL );
	n_win_simplemenu_set( p, N_PAINT_MENU_GRID      , NULL, n_posix_literal( "[ ]2 : Grid"               ), NULL );
	n_win_simplemenu_set( p, N_PAINT_MENU_PIXELGRID , NULL, n_posix_literal( "[ ]3 : Pixel Grid"         ), NULL );
	n_win_simplemenu_set( p, N_PAINT_MENU_THUMBNAIL , NULL, n_posix_literal( "[ ]4 : Thumbnail"          ), NULL );
	n_win_simplemenu_set( p, N_PAINT_MENU_GRAYCANVAS, NULL, n_posix_literal( "[ ]5 : Gray Canvas"        ), NULL );
	n_win_simplemenu_set( p, N_PAINT_MENU_LINE2     , NULL, n_posix_literal( "[-]"                       ), NULL );
	n_win_simplemenu_set( p, N_PAINT_MENU_CLR_CANVAS, NULL, n_posix_literal( "[ ]6 : Clear Canvas"       ), NULL );
	n_win_simplemenu_set( p, N_PAINT_MENU_ALPHA     , NULL, n_posix_literal( "[ ]7 : Alpha Tweaker"      ), NULL );
	n_win_simplemenu_set( p, N_PAINT_MENU_REPLACER  , NULL, n_posix_literal( "[ ]8 : Color Replacer"     ), NULL );
	n_win_simplemenu_set( p, N_PAINT_MENU_LINE3     , NULL, n_posix_literal( "[-]"                       ), NULL );
	n_win_simplemenu_set( p, N_PAINT_MENU_INI2GDI   , NULL, n_posix_literal( "[ ]9 : Output ini2gdi.ini" ), NULL );
	n_win_simplemenu_set( p, N_PAINT_MENU_LINE4     , NULL, n_posix_literal( "[-]"                       ), NULL );
	n_win_simplemenu_set( p, N_PAINT_MENU_PROPERTY  , NULL, n_posix_literal( "[ ]0 : Used Colors"        ), NULL );


	return;
}

void
n_paint_menu_toggle( int command )
{

	if ( n_win_simplemenu_detect_literal( &n_paint_simplemenu, command, 'v' ) )
	{
		n_win_simplemenu_tweak_literal( &n_paint_simplemenu, command, ' ' );
	} else {
		n_win_simplemenu_tweak_literal( &n_paint_simplemenu, command, 'v' );
	}


	return;
}

void
n_paint_menu_main( int command, n_bool direct_call )
{

	if ( n_paint_pen_start ) { return; }


	n_posix_char c = n_posix_literal( ' ' );
	if ( direct_call ) { c = n_posix_literal( 'v' ); }


	if ( command == N_PAINT_MENU_PREVIEW )
	{

		static HWND hpreview = NULL;

		if ( IsWindow( hpreview ) )
		{
			n_win_message_send( hpreview, WM_CLOSE, 0,0 );
		} else {
			n_win_gui( hwnd_main, WINDOW, n_paint_preview_wndproc, &hpreview );
		}

	} else
	if ( command == N_PAINT_MENU_GRID )
	{

		if ( direct_call ) { n_paint_menu_toggle( command ); }


		n_bool prev = grid;

		grid = n_win_simplemenu_detect( &n_paint_simplemenu, N_PAINT_MENU_GRID, c );
//n_win_hwndprintf_literal( hwnd_main, " %d %d ", grid, prev );

		if ( prev != grid ) { n_paint_refresh_all(); }

	} else
	if ( command == N_PAINT_MENU_PIXELGRID )
	{

		if ( direct_call ) { n_paint_menu_toggle( command ); }


		n_bool prev = pixelgrid;

		pixelgrid = n_win_simplemenu_detect( &n_paint_simplemenu, N_PAINT_MENU_PIXELGRID, c );

		if ( prev != pixelgrid ) { n_paint_refresh_all(); }

	} else
	if ( command == N_PAINT_MENU_THUMBNAIL )
	{

		if ( direct_call ) { n_paint_menu_toggle( command ); }


		n_bool prev = thumbnail;

		thumbnail = n_win_simplemenu_detect( &n_paint_simplemenu, N_PAINT_MENU_THUMBNAIL, c );

		if ( prev != thumbnail ) { n_paint_thumbnail_show(); }

	} else
	if ( command == N_PAINT_MENU_GRAYCANVAS )
	{

		if ( direct_call ) { n_paint_menu_toggle( command ); }


		n_bool prev = graycanvas;

		graycanvas = n_win_simplemenu_detect( &n_paint_simplemenu, N_PAINT_MENU_GRAYCANVAS, c );

		if ( prev != graycanvas ) { n_paint_refresh_all(); }

	} else
	if ( command == N_PAINT_MENU_CLR_CANVAS )
	{

		HWND hpopup;
		n_win_gui( hwnd_main, WINDOW, n_paint_clearcanvas_wndproc, &hpopup );

	} else
	if ( command == N_PAINT_MENU_ALPHA )
	{

		HWND hpopup;
		n_win_gui( hwnd_main, WINDOW, n_paint_alphatweaker_wndproc, &hpopup );

	} else
	if ( command == N_PAINT_MENU_REPLACER )
	{

		HWND hpopup;
		n_win_gui( hwnd_main, WINDOW, n_paint_colorreplacer_wndproc, &hpopup );

	} else
	if ( command == N_PAINT_MENU_INI2GDI )
	{

		n_resource_save_literal( "NONNON_PAINT_INI2GDI", "DATA", "ini2gdi.ini" );

		n_explorer_refresh( n_false );

	} else
	if ( command == N_PAINT_MENU_PROPERTY )
	{

		n_win_cursor_add( NULL, IDC_WAIT );

		n_paint_property_usedcolors( n_paint_layer_data );

		n_win_cursor_add( NULL, IDC_ARROW );

	} //else


	return;
}

void
n_paint_menu_proc( HWND hwnd, UINT msg, WPARAM *wparam, LPARAM *lparam )
{

	switch( msg ) {


	case WM_COMMAND : 
	{

		HWND h = (HWND) (*lparam);

		if ( h != n_paint_simplemenu.hwnd ) { break; }


		if ( (*wparam) == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
		{

			if ( grid )
			{
				n_win_simplemenu_tweak_literal( &n_paint_simplemenu, N_PAINT_MENU_GRID, 'v' );
			} else {
				n_win_simplemenu_tweak_literal( &n_paint_simplemenu, N_PAINT_MENU_GRID, ' ' );
			}

			if ( pixelgrid )
			{
				n_win_simplemenu_tweak_literal( &n_paint_simplemenu, N_PAINT_MENU_PIXELGRID, 'v' );
			} else {
				n_win_simplemenu_tweak_literal( &n_paint_simplemenu, N_PAINT_MENU_PIXELGRID, ' ' );
			}

			if ( thumbnail )
			{
				n_win_simplemenu_tweak_literal( &n_paint_simplemenu, N_PAINT_MENU_THUMBNAIL, 'v' );
			} else {
				n_win_simplemenu_tweak_literal( &n_paint_simplemenu, N_PAINT_MENU_THUMBNAIL, ' ' );
			}

			if ( graycanvas )
			{
				n_win_simplemenu_tweak_literal( &n_paint_simplemenu, N_PAINT_MENU_GRAYCANVAS, 'v' );
			} else {
				n_win_simplemenu_tweak_literal( &n_paint_simplemenu, N_PAINT_MENU_GRAYCANVAS, ' ' );
			}

		} else {

			n_paint_menu_main( (*wparam), n_false );

			// [!] : for hamburger button
			n_paint_refresh_client();

		}

	}
	break;


	} // switch


	n_win_simplemenu_proc( hwnd, msg, wparam, lparam, &n_paint_simplemenu );


	return;
}

